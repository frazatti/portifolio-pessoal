
import React from 'react';
import { UserIcon } from './icons/UserIcon';

const SectionTitle: React.FC<{ icon: React.ReactNode; title: string }> = ({ icon, title }) => (
  <h2 className="text-3xl font-bold text-white mb-8 flex items-center justify-center gap-3">
    {icon}
    <span>{title}</span>
  </h2>
);

const About: React.FC = () => {
  return (
    <section id="sobre" className="py-20">
      <SectionTitle icon={<UserIcon />} title="Sobre Mim" />
      <div className="text-center max-w-3xl mx-auto">
        <p className="text-lg text-gray-300 leading-relaxed text-balance">
          Olá! Sou um desenvolvedor de software com mais de 5 anos de experiência, focado em criar soluções web robustas e escaláveis. Minha jornada na programação começou com um fascínio por como a tecnologia pode transformar ideias em realidade, e essa paixão continua a me impulsionar todos os dias.
        </p>
        <br />
        <p className="text-lg text-gray-300 leading-relaxed text-balance">
          Especializado no ecossistema JavaScript, com profundo conhecimento em React, TypeScript e Node.js, busco sempre as melhores práticas de desenvolvimento para entregar produtos de alta qualidade. Fora do código, gosto de explorar trilhas, ler ficção científica e experimentar novas receitas na cozinha.
        </p>
      </div>
    </section>
  );
};

export default About;
