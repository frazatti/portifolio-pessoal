
import React from 'react';
import { GithubIcon } from './icons/GithubIcon';
import { LinkedinIcon } from './icons/LinkedinIcon';

const Hero: React.FC = () => {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center -mt-20">
      <div className="text-center">
        <img
          src="https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80"
          alt="Foto de Perfil de Cláudio Gardenal"
          className="w-48 h-48 rounded-full mx-auto mb-6 border-4 border-cyan-400 shadow-lg"
        />
        <h1 className="text-4xl md:text-6xl font-extrabold text-white mb-2">
          Cláudio Gardenal
        </h1>
        <p className="text-xl md:text-2xl font-light text-cyan-400 mb-6 text-balance">
          Desenvolvedor Frontend & Especialista em React
        </p>
        <p className="max-w-2xl mx-auto text-lg text-gray-300 mb-8 text-balance">
          Apaixonado por criar interfaces de usuário intuitivas, performáticas e visualmente atraentes que resolvem problemas reais.
        </p>
        <div className="flex justify-center space-x-6">
          <a href="#projetos" className="bg-cyan-500 text-white font-bold py-3 px-8 rounded-full hover:bg-cyan-600 transition-transform transform hover:scale-105 shadow-lg">
            Meus Projetos
          </a>
          <a href="mailto:claudio.gardenal@email.com" className="bg-gray-700 text-white font-bold py-3 px-8 rounded-full hover:bg-gray-600 transition-transform transform hover:scale-105 shadow-lg">
            Contato
          </a>
        </div>
        <div className="flex justify-center mt-10 space-x-6">
          <a href="https://github.com/claudiogardenaldev" target="_blank" rel="noopener noreferrer" aria-label="Github" className="text-gray-400 hover:text-cyan-400 transition-colors">
            <GithubIcon />
          </a>
          <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn" className="text-gray-400 hover:text-cyan-400 transition-colors">
            <LinkedinIcon />
          </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;
