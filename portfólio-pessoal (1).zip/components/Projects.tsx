
import React from 'react';
import type { Project } from '../types';
import { ProjectIcon } from './icons/ProjectIcon';
import { GithubIcon } from './icons/GithubIcon';
import { ExternalLinkIcon } from './icons/ExternalLinkIcon';

const projectsData: Project[] = [
  {
    title: 'Plataforma de E-learning',
    description: 'Uma plataforma interativa para cursos online, com trilhas de aprendizado, quizzes e emissão de certificados.',
    tags: ['React', 'Next.js', 'TypeScript', 'Stripe'],
    imageUrl: 'https://picsum.photos/seed/project1/400/300',
    liveUrl: '#',
    repoUrl: '#',
  },
  {
    title: 'Sistema de Gerenciamento de Tarefas',
    description: 'Um aplicativo Kanban para gerenciamento de projetos pessoais e de equipe, com drag-and-drop e notificações em tempo real.',
    tags: ['React', 'Firebase', 'Tailwind CSS', 'Vite'],
    imageUrl: 'https://picsum.photos/seed/project2/400/300',
    liveUrl: '#',
    repoUrl: '#',
  },
  {
    title: 'Dashboard de Análise de Dados',
    description: 'Visualização de dados complexos de forma intuitiva, com gráficos interativos e filtros dinâmicos para business intelligence.',
    tags: ['React', 'D3.js', 'TypeScript', 'Styled Components'],
    imageUrl: 'https://picsum.photos/seed/project3/400/300',
    repoUrl: '#',
  },
  {
    title: 'Landing Page para Startup',
    description: 'Página de marketing responsiva e otimizada para SEO, com foco em conversão de leads e apresentação do produto.',
    tags: ['HTML5', 'CSS3', 'JavaScript', 'GSAP'],
    imageUrl: 'https://picsum.photos/seed/project4/400/300',
    liveUrl: '#',
  },
];

const ProjectCard: React.FC<{ project: Project }> = ({ project }) => {
  return (
    <div className="bg-gray-800 rounded-lg overflow-hidden shadow-lg group transition-all duration-300 hover:shadow-cyan-500/30 hover:-translate-y-2">
      <img src={project.imageUrl} alt={project.title} className="w-full h-48 object-cover" />
      <div className="p-6">
        <h3 className="text-xl font-bold text-white mb-2">{project.title}</h3>
        <p className="text-gray-400 mb-4 text-sm leading-relaxed">{project.description}</p>
        <div className="flex flex-wrap gap-2 mb-4">
          {project.tags.map((tag) => (
            <span key={tag} className="bg-gray-700 text-cyan-400 text-xs font-semibold px-2.5 py-1 rounded-full">
              {tag}
            </span>
          ))}
        </div>
        <div className="flex justify-end space-x-4">
          {project.repoUrl && (
            <a href={project.repoUrl} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-cyan-400 transition-colors">
              <GithubIcon size={24}/>
            </a>
          )}
          {project.liveUrl && (
            <a href={project.liveUrl} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-cyan-400 transition-colors">
              <ExternalLinkIcon size={24}/>
            </a>
          )}
        </div>
      </div>
    </div>
  );
};


const SectionTitle: React.FC<{ icon: React.ReactNode; title: string }> = ({ icon, title }) => (
  <h2 className="text-3xl font-bold text-white mb-12 flex items-center justify-center gap-3">
    {icon}
    <span>{title}</span>
  </h2>
);

const Projects: React.FC = () => {
  return (
    <section id="projetos" className="py-20">
      <SectionTitle icon={<ProjectIcon />} title="Meus Projetos" />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8 max-w-5xl mx-auto">
        {projectsData.map((project) => (
          <ProjectCard key={project.title} project={project} />
        ))}
      </div>
    </section>
  );
};

export default Projects;
