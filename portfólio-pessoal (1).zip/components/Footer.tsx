
import React from 'react';
import { GithubIcon } from './icons/GithubIcon';
import { LinkedinIcon } from './icons/LinkedinIcon';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-800 border-t border-gray-700">
      <div className="container mx-auto px-6 md:px-12 lg:px-20 py-8">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm mb-4 md:mb-0">
            &copy; {currentYear} Cláudio Gardenal. Todos os direitos reservados.
          </p>
          <div className="flex space-x-6">
            <a href="https://github.com/claudiogardenaldev" target="_blank" rel="noopener noreferrer" aria-label="Github" className="text-gray-400 hover:text-cyan-400 transition-colors">
              <GithubIcon />
            </a>
            <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn" className="text-gray-400 hover:text-cyan-400 transition-colors">
              <LinkedinIcon />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
