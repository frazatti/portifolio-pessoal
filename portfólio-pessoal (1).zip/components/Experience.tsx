
import React from 'react';
import type { ExperienceItem } from '../types';
import { BriefcaseIcon } from './icons/BriefcaseIcon';

const experienceData: ExperienceItem[] = [
  {
    role: 'Desenvolvedor Frontend Sênior',
    company: 'Tech Solutions Inc.',
    period: 'Jan 2021 - Presente',
    description: [
      'Liderança no desenvolvimento de interfaces para a principal plataforma SaaS da empresa, utilizando React e TypeScript.',
      'Otimização de performance da aplicação, resultando em uma redução de 40% no tempo de carregamento.',
      'Mentoria de desenvolvedores júnior e participação ativa na definição de boas práticas de código.'
    ],
  },
  {
    role: 'Desenvolvedor Pleno',
    company: 'Innovate Digital',
    period: 'Jun 2018 - Dez 2020',
    description: [
      'Desenvolvimento e manutenção de e-commerces de grande escala com Next.js.',
      'Colaboração com equipes de UX/UI para transformar wireframes em componentes interativos e responsivos.',
      'Integração com diversas APIs de pagamento e logística.'
    ],
  },
  {
    role: 'Desenvolvedor Júnior',
    company: 'Web Starters',
    period: 'Mar 2016 - Mai 2018',
    description: [
      'Criação de websites institucionais e landing pages utilizando HTML, CSS e JavaScript.',
      'Primeiros contatos com React e construção de pequenos componentes reutilizáveis.',
      'Manutenção de sistemas legados e correção de bugs.'
    ],
  },
];

const SectionTitle: React.FC<{ icon: React.ReactNode; title: string }> = ({ icon, title }) => (
  <h2 className="text-3xl font-bold text-white mb-12 flex items-center justify-center gap-3">
    {icon}
    <span>{title}</span>
  </h2>
);


const Experience: React.FC = () => {
  return (
    <section id="experiencia" className="py-20">
      <SectionTitle icon={<BriefcaseIcon />} title="Experiência Profissional" />
      <div className="relative max-w-3xl mx-auto">
        <div className="absolute left-1/2 w-0.5 h-full bg-gray-700 transform -translate-x-1/2"></div>
        {experienceData.map((item, index) => (
          <div key={index} className="mb-12 flex justify-between items-center w-full">
            <div className={`order-1 w-5/12 ${index % 2 === 0 ? 'text-right' : ''}`}></div>
            <div className="z-10 flex items-center order-1 bg-cyan-500 shadow-xl w-8 h-8 rounded-full">
              <div className="mx-auto text-white font-semibold text-lg">{experienceData.length - index}</div>
            </div>
            <div className={`order-1 bg-gray-800 rounded-lg shadow-xl w-5/12 px-6 py-4 ${index % 2 === 0 ? '' : 'text-right'}`}>
              <h3 className="mb-2 font-bold text-cyan-400 text-xl">{item.role}</h3>
              <p className="text-sm font-medium leading-snug tracking-wide text-gray-400 mb-2">{item.company} | {item.period}</p>
              <ul className={`list-disc ${index % 2 === 0 ? 'list-inside text-left' : 'list-inside text-right'}`}>
                  {item.description.map((desc, i) => (
                      <li key={i} className="text-gray-300 text-sm leading-relaxed">{desc}</li>
                  ))}
              </ul>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Experience;
