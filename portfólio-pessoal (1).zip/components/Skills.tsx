
import React from 'react';
import type { Skill } from '../types';
import { CodeIcon } from './icons/CodeIcon';

const SkillCard: React.FC<{ skill: Skill }> = ({ skill }) => (
  <div className="bg-gray-800 p-6 rounded-lg flex flex-col items-center justify-center text-center transition-transform transform hover:-translate-y-2 hover:shadow-cyan-500/20 shadow-lg">
    <div className="text-cyan-400 mb-3">{skill.icon}</div>
    <h3 className="text-lg font-semibold text-white">{skill.name}</h3>
  </div>
);

const SectionTitle: React.FC<{ icon: React.ReactNode; title: string }> = ({ icon, title }) => (
  <h2 className="text-3xl font-bold text-white mb-12 flex items-center justify-center gap-3">
    {icon}
    <span>{title}</span>
  </h2>
);


const TechIcon: React.FC<{ d: string }> = ({ d }) => (
    <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="currentColor">
        <path d={d}></path>
    </svg>
);


const skillsData: Skill[] = [
  { name: 'React', icon: <TechIcon d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-4.5-8.5c.83 0 1.5.67 1.5 1.5s-.67 1.5-1.5 1.5-1.5-.67-1.5-1.5.67-1.5 1.5-1.5zm4.5 0c.83 0 1.5.67 1.5 1.5s-.67 1.5-1.5 1.5-1.5-.67-1.5-1.5.67-1.5 1.5-1.5zm4.5 0c.83 0 1.5.67 1.5 1.5s-.67 1.5-1.5 1.5-1.5-.67-1.5-1.5.67-1.5 1.5-1.5zM12 16.5c2.76 0 5-2.24 5-5H7c0 2.76 2.24 5 5 5z" /> },
  { name: 'TypeScript', icon: <TechIcon d="M21.5 2.5h-19A2.5 2.5 0 000 5v14a2.5 2.5 0 002.5 2.5h19A2.5 2.5 0 0024 19V5a2.5 2.5 0 00-2.5-2.5zM10.1 18.9h-3V9.1h3v9.8zM8.6 7.9a1.6 1.6 0 110-3.2 1.6 1.6 0 010 3.2zm11.3 11h-3V14c0-1.2-.4-2-1.5-2-.8 0-1.3.5-1.5 1-.1.2-.1.4-.1.6v5.3h-3s.1-8.9 0-9.8h3v1.3c.4-.7 1.2-1.7 2.7-1.7 2 0 3.4 1.3 3.4 4.1v6.1z" /> },
  { name: 'JavaScript', icon: <TechIcon d="M21.5 2.5h-19A2.5 2.5 0 000 5v14a2.5 2.5 0 002.5 2.5h19A2.5 2.5 0 0024 19V5a2.5 2.5 0 00-2.5-2.5zM9.9 17.5H7.7V9.3h2.2v8.2zM8.8 8.4a1.2 1.2 0 110-2.4 1.2 1.2 0 010 2.4zm10 9.1h-2.2v-4.8c0-.9-.3-1.5-1.1-1.5-.6 0-1 .4-1.1.8-.1.1-.1.3-.1.5v5h-2.2s.1-7.4 0-8.2h2.2v1c.3-.5 1-1.2 2-1.2 1.4 0 2.4.9 2.4 2.8v5.6z" /> },
  { name: 'Node.js', icon: <TechIcon d="M22.4 12.3c0-5.4-4.4-9.8-9.8-9.8s-9.8 4.4-9.8 9.8c0 4.6 3.2 8.5 7.5 9.5.5.1 1-.2 1-.7v-2.5c-3.1.7-3.8-1.5-3.8-1.5-.5-1.2-1.2-1.5-1.2-1.5-1-.7.1-.6.1-.6 1.1.1 1.7 1.1 1.7 1.1 1 .7 2.5.5 3.1.4.1-.3.4-.5.7-.6-2.4-.3-4.9-1.2-4.9-5.2 0-1.2.4-2.1 1.1-2.9-.1-.3-.5-1.4.1-2.8 0 0 .9-.3 3 1.1.9-.2 1.8-.4 2.7-.4s1.8.1 2.7.4c2.1-1.4 3-1.1 3-1.1.6 1.4.2 2.5.1 2.8.7.7 1.1 1.7 1.1 2.9 0 4-2.5 4.9-4.9 5.2.4.3.8.9.8 1.8v2.9c0 .5.4.8 1 .7 4.3-1 7.5-4.9 7.5-9.5z" /> },
  { name: 'Next.js', icon: <TechIcon d="M12 2L2 7l10 5 10-5L12 2zm-8.2 6.5L12 15.3l8.2-6.8L12 5.7 3.8 8.5zM2 17l10 5 10-5-10-5-10 5z" /> },
  { name: 'Tailwind CSS', icon: <TechIcon d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" /> },
  { name: 'Figma', icon: <TechIcon d="M15 2c-3.86 0-7 3.14-7 7s3.14 7 7 7 7-3.14 7-7-3.14-7-7-7zm0 12c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm-7-7c-2.76 0-5 2.24-5 5s2.24 5 5 5V9z" /> },
  { name: 'Git', icon: <TechIcon d="M21.6 8.4l-9-8.4c-.4-.3-.9-.3-1.2 0l-9 8.4c-.4.4-.4 1 0 1.4l9 8.4c.4.3.9.3 1.2 0l9-8.4c.4-.4.4-1 0-1.4zM12 17L5 12l7-5 7 5-7 5zm-1-8.4V12l-5-4.2L11 3v4.6z" /> },
];


const Skills: React.FC = () => {
  return (
    <section id="habilidades" className="py-20 bg-gray-900">
      <SectionTitle icon={<CodeIcon />} title="Habilidades Técnicas" />
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6 max-w-5xl mx-auto">
        {skillsData.map((skill) => (
          <SkillCard key={skill.name} skill={skill} />
        ))}
      </div>
    </section>
  );
};

export default Skills;
